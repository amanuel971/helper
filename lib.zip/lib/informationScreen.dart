// import 'package:flutter/material.dart';

// class MyScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('information'),
//       ),
//       body: Center(
//         child: Text(
//           'Line 1\nLine 2\nLine 3',
//           style: TextStyle(fontSize: 16.0),
//           textAlign: TextAlign.center,
//         ),
//       ),
//     );
//   }
// }
