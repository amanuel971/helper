// import 'package:flutter/material.dart';
// import 'package:helper/main.dart';

// void main() {
//   runApp(MaterialApp(
//     home: Welcome(),
//   ));
// }

// class Welcome extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Welcome'),
//       ),
//       body: Column(
//         children: [
//           SizedBox(height: 400),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//             children: [
//               Column(
//                 children: [
//                   ElevatedButton(
//                     onPressed: () {
//                       Navigator.of(context).push(
//                         MaterialPageRoute(builder: (context) => HomePage()),
//                       );
//                     },
//                     child: Text('Next'),
//                   )
//                 ],
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }
